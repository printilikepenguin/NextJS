export const songList = [
  { title: "배기진스", author: "nct u", id: "s93if39" },
  { title: "maniac", author: "Felix", id: "3if39" },
  { title: "뭐야벌써아침이네", author: "하치와레", id: "s93isdff39" },
  { title: "Love DROP", author: "SAAY", id: "s93i32tf39" },
];
